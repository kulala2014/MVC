using System;
using System.Collections.Generic;
using System.Text;

namespace MVCBricks.Core.Shapes
{
    public class ZShape : BaseShape
    {
        public ZShape() : base(3, 2, "110011")
        {
        }
    }
}
