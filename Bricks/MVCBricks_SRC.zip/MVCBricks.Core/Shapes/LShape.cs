using System;
using System.Collections.Generic;
using System.Text;

namespace MVCBricks.Core.Shapes
{
    public class LShape : BaseShape
    {
        public LShape() : base(3, 2, "111001")
        {
        }
    }
}
